---
title: "YZOMANDIAS: KRÁL SCÉNY SE VRACÍ"
excerpt: "Hlava Milion+ se vrací s novým projektem, který mění pravidla hry. Exkluzivní pohled do zákulisí příprav."
author: "Redakce"
date: "2024-05-20"
category: "RAPPERS"
tags: ["MILION+", "YZO", "NOVINKA"]
imageUrl: "https://picsum.photos/seed/yzo/800/600"
---

## Král je zpět

Yzomandias, vlastním jménem Jakub Vlček, znovu dokazuje, proč je na vrcholu potravního řetězce české rapové scény. Jeho nejnovější projekt není jen album, je to manifest.

## Nový zvuk

Produkce se ujali dlouholetí spolupracovníci, ale slyšíme i nové vlivy drillu a elektroniky.

* "Melanž" - absolutní banger
* "Rodina" - osobní zpověď

> "Nedělám rap pro fame, dělám to pro kulturu."

Očekávání jsou obrovská.